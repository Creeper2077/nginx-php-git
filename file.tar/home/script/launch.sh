service cron start
service php7.4-fpm start
service nginx start